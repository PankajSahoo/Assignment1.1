# Assignment1.1
1.a).  Prescriptive Analytics used to predict the future outcomes?
Ans: False


1.b) Base R packages installed automatically?
 Ans:True
 
 
2. What is Recycling of elements in a vector?
When applying an operation to two vectors that requires them to be the same length, R automatically recycles, or repeats, the shorter one,
until it is long enough to match the longer one.



3. Give an example of recycling of elements.
> c(5,6,8) + c(8,2,11,22,24)
[1]  13 8 19 27 32
